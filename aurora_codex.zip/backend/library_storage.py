"""Supabase-backed library storage for magic items + spells.

Shared library used by every player. Same wire protocol as the other
storage helpers (httpx synchronous; FastAPI wraps with run_in_threadpool).
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from typing import Optional

import httpx

logger = logging.getLogger(__name__)

MAGIC_ITEMS_TABLE = "aurora_magic_items"
SPELLS_TABLE = "aurora_spells"
_TIMEOUT = httpx.Timeout(15.0, connect=10.0)


def _base_url() -> str:
    url = os.environ["SUPABASE_URL"].rstrip("/")
    if url.endswith("/rest/v1"):
        url = url[: -len("/rest/v1")]
    return url


def _headers(prefer: str = "") -> dict:
    key = os.environ["SUPABASE_SECRET_KEY"]
    h = {
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }
    if prefer:
        h["Prefer"] = prefer
    return h


def _rest(path: str) -> str:
    return f"{_base_url()}/rest/v1/{path.lstrip('/')}"


def _client() -> httpx.Client:
    return httpx.Client(timeout=_TIMEOUT)


# ── magic items ──────────────────────────────────────────────────────

def list_magic_items() -> list[dict]:
    with _client() as c:
        r = c.get(_rest(MAGIC_ITEMS_TABLE) + "?select=*&order=name.asc",
                  headers=_headers())
        r.raise_for_status()
        return r.json() or []


def create_magic_item(payload: dict) -> dict:
    with _client() as c:
        r = c.post(_rest(MAGIC_ITEMS_TABLE), headers=_headers("return=representation"),
                   json=[payload])
        r.raise_for_status()
        rows = r.json() or []
        return rows[0] if rows else payload


def update_magic_item(item_id: str, payload: dict) -> Optional[dict]:
    with _client() as c:
        r = c.patch(_rest(MAGIC_ITEMS_TABLE) + f"?id=eq.{item_id}",
                    headers=_headers("return=representation"), json=payload)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        rows = r.json() or []
        return rows[0] if rows else None


def delete_magic_item(item_id: str) -> bool:
    with _client() as c:
        r = c.delete(_rest(MAGIC_ITEMS_TABLE) + f"?id=eq.{item_id}",
                     headers=_headers("return=minimal"))
        r.raise_for_status()
        return True


# ── spells ───────────────────────────────────────────────────────────

def list_spells() -> list[dict]:
    with _client() as c:
        r = c.get(_rest(SPELLS_TABLE) + "?select=*&order=level.asc,name.asc",
                  headers=_headers())
        r.raise_for_status()
        return r.json() or []


def create_spell(payload: dict) -> dict:
    with _client() as c:
        r = c.post(_rest(SPELLS_TABLE), headers=_headers("return=representation"),
                   json=[payload])
        r.raise_for_status()
        rows = r.json() or []
        return rows[0] if rows else payload


def update_spell(spell_id: str, payload: dict) -> Optional[dict]:
    with _client() as c:
        r = c.patch(_rest(SPELLS_TABLE) + f"?id=eq.{spell_id}",
                    headers=_headers("return=representation"), json=payload)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        rows = r.json() or []
        return rows[0] if rows else None


def delete_spell(spell_id: str) -> bool:
    with _client() as c:
        r = c.delete(_rest(SPELLS_TABLE) + f"?id=eq.{spell_id}",
                     headers=_headers("return=minimal"))
        r.raise_for_status()
        return True
