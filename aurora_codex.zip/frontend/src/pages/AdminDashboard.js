import React, { useEffect, useMemo, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { api, formatApiErrorDetail } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import Navbar from "../components/Navbar";
import { toast } from "sonner";

function formatErr(e) {
  if (e?.response?.data?.detail) return formatApiErrorDetail(e.response.data.detail);
  return e?.message || "Something went wrong.";
}

function RoleBadge({ role }) {
  const isAdmin = role === "admin";
  return (
    <span
      data-testid="admin-user-role"
      className={`font-cinzel text-[9px] tracking-[0.2em] uppercase px-2 py-0.5 border ${
        isAdmin
          ? "text-crimson border-crimson/50 bg-crimson/10"
          : "text-parchment-muted border-edge bg-ink/40"
      }`}
    >
      {role || "user"}
    </span>
  );
}

function UserRow({ u, onOpenChar }) {
  const [open, setOpen] = useState(false);
  const [chars, setChars] = useState(null); // null = not loaded
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const toggle = async () => {
    const next = !open;
    setOpen(next);
    if (next && chars === null) {
      setLoading(true);
      setErr("");
      try {
        const res = await api.get(`/admin/users/${u.username}/characters`);
        setChars(res.data);
      } catch (e) {
        setErr(formatErr(e));
        setChars([]);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div
      data-testid={`admin-user-${u.username}`}
      className="bg-ink-surface border border-edge hover:border-gold/40 transition-colors"
    >
      <button
        type="button"
        onClick={toggle}
        data-testid={`admin-user-toggle-${u.username}`}
        className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left"
      >
        <div className="min-w-0 flex items-center gap-4">
          <span className="font-cinzel text-gold text-xl leading-none shrink-0">❖</span>
          <div className="min-w-0">
            <p className="font-cinzel text-parchment text-base tracking-wide truncate">
              {u.name || u.username}
            </p>
            <p className="font-cormorant italic text-parchment-muted text-sm">
              @{u.username}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4 shrink-0">
          <RoleBadge role={u.role} />
          <span
            data-testid={`admin-user-charcount-${u.username}`}
            className="font-cormorant text-parchment-dim text-sm whitespace-nowrap"
          >
            {u.character_count < 0 ? "—" : `${u.character_count} character${u.character_count === 1 ? "" : "s"}`}
          </span>
          <span className={`font-cinzel text-gold transition-transform ${open ? "rotate-90" : ""}`}>›</span>
        </div>
      </button>

      {open && (
        <div className="border-t border-edge px-5 py-4 bg-ink/40">
          {loading ? (
            <p data-testid={`admin-chars-loading-${u.username}`} className="font-cormorant italic text-parchment-muted text-sm">
              ❖ Consulting the tomes…
            </p>
          ) : err ? (
            <p className="text-crimson font-cormorant text-sm">{err}</p>
          ) : chars && chars.length === 0 ? (
            <p className="font-cormorant italic text-parchment-dim text-sm">No characters for this user.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {(chars || []).map((ch) => (
                <div
                  key={ch.id}
                  data-testid={`admin-char-${ch.id}`}
                  className="border border-edge bg-ink-surface p-4 flex flex-col gap-3"
                >
                  <div className="min-w-0">
                    <p className="font-cinzel text-parchment text-sm truncate">{ch.name || "Unnamed"}</p>
                    <p className="font-cormorant italic text-parchment-muted text-xs mt-0.5">
                      {ch.char_class || "—"} · Level {ch.level || 1}
                    </p>
                  </div>
                  <button
                    onClick={() => onOpenChar(u.username, ch.id)}
                    data-testid={`admin-char-open-${ch.id}`}
                    className="px-3 py-1.5 border border-gold/60 text-gold hover:bg-gold/10 font-cinzel text-[10px] tracking-[0.2em] uppercase btn-press self-start"
                  >
                    Open &amp; Edit
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function AdminDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [users, setUsers] = useState(null);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");

  useEffect(() => {
    if (!user || user === false || user.role !== "admin") return;
    let cancelled = false;
    (async () => {
      try {
        const res = await api.get("/admin/users");
        if (!cancelled) setUsers(res.data);
      } catch (e) {
        if (!cancelled) {
          setError(formatErr(e));
          setUsers([]);
        }
      }
    })();
    return () => { cancelled = true; };
  }, [user]);

  const filtered = useMemo(() => {
    if (!users) return null;
    const q = query.trim().toLowerCase();
    if (!q) return users;
    return users.filter(
      (u) =>
        (u.username || "").toLowerCase().includes(q) ||
        (u.name || "").toLowerCase().includes(q)
    );
  }, [users, query]);

  // Gate: non-admins bounce to dashboard.
  if (user === null) return null; // AuthProvider still resolving
  if (user === false) return <Navigate to="/login" replace />;
  if (user.role !== "admin") {
    toast.error("Admin access required.");
    return <Navigate to="/dashboard" replace />;
  }

  const openChar = (username, charId) => {
    navigate(`/sheet?id=${charId}&adminUser=${encodeURIComponent(username)}`);
  };

  return (
    <div className="min-h-screen bg-leather">
      <Navbar />
      <main className="pt-32 pb-20 px-6 sm:px-10">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6 mb-10">
            <div>
              <p className="font-cinzel text-crimson text-xs tracking-[0.4em] uppercase mb-3">
                ❖ Dungeon Master Vault
              </p>
              <h1 data-testid="admin-title" className="font-cinzel text-parchment text-4xl sm:text-5xl">
                All Characters
              </h1>
              <p className="mt-3 font-cormorant italic text-parchment-muted text-lg">
                Every adventurer in the realm. Expand a player to browse and edit their sheets.
              </p>
            </div>
            <div className="w-full sm:w-72">
              <input
                data-testid="admin-user-search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search players…"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment rounded-none text-sm"
              />
            </div>
          </div>

          <div className="divider-gold mb-8 max-w-3xl" />

          {error && (
            <div
              data-testid="admin-error"
              className="text-crimson border border-crimson/30 bg-crimson/10 px-4 py-3 font-cormorant mb-8"
            >
              {error}
            </div>
          )}

          {filtered === null ? (
            <p data-testid="admin-loading" className="font-cormorant italic text-parchment-muted">
              ❖ Summoning the roster…
            </p>
          ) : filtered.length === 0 ? (
            <div
              data-testid="admin-empty"
              className="border border-dashed border-edge bg-ink-surface/50 p-12 text-center"
            >
              <h3 className="font-cinzel text-parchment text-2xl mb-3">No players found</h3>
              <p className="font-cormorant italic text-parchment-muted text-lg max-w-md mx-auto">
                {query ? "No one matches that search." : "No registered users yet."}
              </p>
            </div>
          ) : (
            <div data-testid="admin-user-list" className="flex flex-col gap-3">
              {filtered.map((u) => (
                <UserRow key={u.id || u.username} u={u} onOpenChar={openChar} />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
