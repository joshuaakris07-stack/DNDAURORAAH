import React, { useEffect, useRef, useState, useCallback } from "react";
import { Link, useSearchParams, useNavigate, useLocation } from "react-router-dom";
import LibraryBrowser from "../components/LibraryBrowser";
import { api, formatApiErrorDetail } from "../lib/api";
import { unpackFromCloud } from "../lib/assets";
import Navbar from "../components/Navbar";
import { toast } from "sonner";

function formatErr(e) {
  if (e?.response?.data?.detail) return formatApiErrorDetail(e.response.data.detail);
  return e?.message || "Something went wrong.";
}

// Split the stored blob into the clean "main" (Quick Save) character data,
// an optional "__autosave" snapshot, and optional "__slots" (manual save
// slots). These live as reserved sibling keys inside the character JSON so
// the backend keeps working unchanged and the sheet ignores them.
function splitBlob(blob) {
  const b = blob && typeof blob === "object" ? blob : {};
  const { __autosave, __slots, ...main } = b;
  const auto = __autosave && typeof __autosave === "object" ? __autosave : null;
  const slots = Array.isArray(__slots) ? __slots.filter((s) => s && typeof s === "object" && s.data) : [];
  return { main, auto, slots };
}

function tsOf(obj, key) {
  const v = obj && obj[key];
  const n = v ? Date.parse(v) : 0;
  return isNaN(n) ? 0 : n;
}

function relTime(iso) {
  if (!iso) return "";
  const t = Date.parse(iso);
  if (isNaN(t)) return "";
  const diff = Math.max(0, Date.now() - t);
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

const MAX_SLOTS = 8;

export default function Sheet() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  const charId = params.get("id");
  // Creation-wizard payload handed off by Dashboard via location.state.
  const wizardPayloadRef = useRef(location.state?.wizard || null);
  const wizardAppliedRef = useRef(false);
  // Admin "edit another user's character" mode: /sheet?id=…&adminUser=bob
  const adminUser = params.get("adminUser");
  const charBase = adminUser ? `/admin/users/${adminUser}/characters` : `/characters`;
  const fileInputRef = useRef(null);
  const [meta, setMeta] = useState(null);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const [saveClass, setSaveClass] = useState("");
  const [saveLevel, setSaveLevel] = useState(1);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [downloadUrl, setDownloadUrl] = useState(null);
  // The sheet opens in immersive fullscreen by default; ✕ Exit / Esc
  // reveal the normal view with the full toolbar.
  const [immersive, setImmersive] = useState(true);

  // ── Save-file versions (Quick Save vs Autosave vs Slots) ──────
  const [mainData, setMainData] = useState(null);     // clean Quick Save data
  const [autosaveSnap, setAutosaveSnap] = useState(null); // { ...data, _ts }
  const [slots, setSlots] = useState([]);             // [{id,name,ts,data}]
  const [activeVersion, setActiveVersion] = useState("main");
  const [savesOpen, setSavesOpen] = useState(false);
  const [autoStatus, setAutoStatus] = useState("");   // "Autosaving…" | "Autosaved ✓"
  const [autoEnabled, setAutoEnabled] = useState(true);

  // Single persistent iframe — never remounted, so entering/leaving
  // fullscreen never reloads the sheet (no startup/"Continue" screen).
  const iframeRef = useRef(null);

  // Refs the autosave interval reads without re-subscribing.
  const mainDataRef = useRef(null);
  const autosaveSnapRef = useRef(null);
  const slotsRef = useRef([]);
  const metaRef = useRef(null);
  const savingRef = useRef(false);
  const lastAutoJsonRef = useRef("");
  const activeDataRef = useRef(null);
  const saveCurrentSheetToCloudRef = useRef(null);
  const [libraryOpen, setLibraryOpen] = useState(false);

  // Fetch the admin/DM custom library once and inject it into the sheet's
  // native Spell Browser + Browse Catalog (retries until the iframe is ready).
  useEffect(() => {
    let cancelled = false;
    let tries = 0;
    let timer = null;
    (async () => {
      let items = [];
      let spells = [];
      try {
        const [mi, sp] = await Promise.all([
          api.get("/library/magic-items"),
          api.get("/library/spells"),
        ]);
        items = mi.data || [];
        spells = sp.data || [];
      } catch (_e) { /* library optional */ }
      const push = () => {
        const w = iframeRef.current?.contentWindow;
        if (w && typeof w._setCustomLibrary === "function") {
          w._setCustomLibrary(items, spells);
          return true;
        }
        return false;
      };
      timer = setInterval(() => {
        if (cancelled || push() || ++tries > 60) clearInterval(timer);
      }, 500);
    })();
    return () => { cancelled = true; if (timer) clearInterval(timer); };
  }, []);

  useEffect(() => { mainDataRef.current = mainData; }, [mainData]);
  useEffect(() => { autosaveSnapRef.current = autosaveSnap; }, [autosaveSnap]);
  useEffect(() => { slotsRef.current = slots; }, [slots]);
  useEffect(() => { metaRef.current = meta; }, [meta]);
  useEffect(() => { savingRef.current = saving; }, [saving]);

  useEffect(() => {
    const onKey = (e) => {
      const t = e.target;
      const typing = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable);
      if (e.key === "Escape") { setSavesOpen(false); if (immersive) setImmersive(false); }
      if ((e.key === "f" || e.key === "F") && e.shiftKey && !typing) {
        e.preventDefault();
        setImmersive((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [immersive]);

  const postToIframe = useCallback((payload) => {
    const t = iframeRef.current?.contentWindow;
    try { if (t) t.postMessage(payload, "*"); } catch (_) { /* noop */ }
  }, []);

  const makeDownloadUrl = useCallback((dataObj) => {
    try {
      const blob = new Blob([JSON.stringify(dataObj, null, 2)], { type: "application/json" });
      return URL.createObjectURL(blob);
    } catch (_) { return null; }
  }, []);

  // Reattach the reserved keys (__autosave / __slots) onto a clean blob
  // before writing it to the cloud, so no save path drops the others.
  const withReserved = useCallback((clean, over = {}) => {
    const auto = "auto" in over ? over.auto : autosaveSnapRef.current;
    const sl = "slots" in over ? over.slots : slotsRef.current;
    return {
      ...clean,
      ...(auto ? { __autosave: auto } : {}),
      ...(sl && sl.length ? { __slots: sl } : {}),
    };
  }, []);

  // ── Load the character and split into Quick Save + Autosave + Slots ─
  useEffect(() => {
    if (!charId) {
      setActiveVersion("main");
      activeDataRef.current = null;
      return;
    }
    let revokeUrl;
    (async () => {
      try {
        const res = await api.get(`${charBase}/${charId}`);
        const data = res.data;
        setMeta(data);
        // Rehydrate deduplicated images (asset:// tokens → data URIs) before
        // splitting, so the sheet always receives complete images.
        const rawBlob = unpackFromCloud(data.data);
        const { main, auto, slots: sl } = splitBlob(rawBlob);
        setMainData(main);
        setAutosaveSnap(auto);
        setSlots(sl);
        setSaveName(data.name || "");
        setSaveClass(data.char_class || "");
        setSaveLevel(data.level || 1);

        // Pick the version to show first: the newer of Quick Save / Autosave.
        const mainTs = tsOf(main, "_qsaved_at") || (data.updated_at ? Date.parse(data.updated_at) : 0);
        const autoTs = auto ? tsOf(auto, "_ts") : 0;
        const useAuto = auto && autoTs > mainTs + 1500;
        const chosen = useAuto ? auto : main;
        setActiveVersion(useAuto ? "autosave" : "main");
        activeDataRef.current = chosen;
        lastAutoJsonRef.current = auto ? JSON.stringify(stripTs(auto)) : "";

        const url = makeDownloadUrl(chosen);
        revokeUrl = url;
        setDownloadUrl(url);

        if (useAuto) {
          toast("Loaded your latest autosave (newer than the Quick Save). Use “Saves” to switch.", { duration: 6000 });
        }
      } catch (e) {
        setError(formatErr(e));
      }
    })();
    return () => { if (revokeUrl) URL.revokeObjectURL(revokeUrl); };
  }, [charId, charBase, makeDownloadUrl]);

  // Push the active version into the iframe once the bridge is ready.
  useEffect(() => {
    const dataToPush = activeDataRef.current;
    if (!dataToPush) return;
    const payload = { type: "aurora:load-character", reqId: "init-" + Date.now(), data: dataToPush };
    let attempts = 0;
    let sent = false;

    const applyWizardIfPending = (target) => {
      const wp = wizardPayloadRef.current;
      if (!wp || wizardAppliedRef.current) return;
      try {
        const fn = target?._applyCreationWizard;
        if (typeof fn === 'function') {
          const ok = fn(wp);
          if (ok) {
            wizardAppliedRef.current = true;
            wizardPayloadRef.current = null;
            setTimeout(() => { saveCurrentSheetToCloudRef.current && saveCurrentSheetToCloudRef.current(); }, 800);
            return;
          }
        }
      } catch (_) { /* fall through to postMessage */ }
      try {
        target?.postMessage?.({ type: "aurora:wizard", reqId: "wiz-" + Date.now(), payload: wp }, "*");
        wizardAppliedRef.current = true;
        wizardPayloadRef.current = null;
        setTimeout(() => { saveCurrentSheetToCloudRef.current && saveCurrentSheetToCloudRef.current(); }, 1200);
      } catch (_) { /* iframe gone — ignore */ }
    };

    const onMsg = (ev) => {
      const m = ev && ev.data;
      if (m && m.type === "aurora:ready" && !sent) {
        postToIframe(payload);
        sent = true;
        setTimeout(() => {
          const win = iframeRef.current?.contentWindow;
          if (win) applyWizardIfPending(win);
        }, 300);
      }
    };
    window.addEventListener("message", onMsg);

    const interval = setInterval(() => {
      if (sent || attempts++ > 10) { clearInterval(interval); return; }
      postToIframe(payload);
    }, 250);

    return () => {
      window.removeEventListener("message", onMsg);
      clearInterval(interval);
    };
  }, [meta, postToIframe]);

  const requestCharacterFromIframe = useCallback((silent = false) => {
    const win = iframeRef.current?.contentWindow;
    if (!win) return Promise.reject(new Error("Sheet iframe not ready — please wait a moment and try again."));

    // Same-origin fast path — dramatically more reliable on iPad/mobile.
    try {
      if (typeof win._gatherCharacterJson === 'function') {
        const data = win._gatherCharacterJson();
        if (data) {
          const sum = (typeof win._currentCharSummary === 'function')
            ? win._currentCharSummary()
            : { name: '', char_class: '', level: 1 };
          return Promise.resolve({
            name: sum.name || '',
            char_class: sum.char_class || '',
            level: sum.level || 1,
            data,
          });
        }
      }
    } catch (_) { /* fall through to postMessage */ }

    const reqId = "req-" + Date.now() + "-" + Math.random().toString(36).slice(2);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        window.removeEventListener("message", onMsg);
        reject(new Error(silent ? "timeout" : "The sheet did not respond. Open it, edit something, then try again."));
      }, silent ? 5000 : 8000);
      function onMsg(ev) {
        const m = ev && ev.data;
        if (!m || m.type !== "aurora:character" || m.reqId !== reqId) return;
        clearTimeout(timeout);
        window.removeEventListener("message", onMsg);
        if (!m.ok || !m.data) reject(new Error("Sheet returned no character data — edit the sheet then try again."));
        else resolve({ name: m.name, char_class: m.char_class, level: m.level, data: m.data });
      }
      window.addEventListener("message", onMsg);
      win.postMessage({ type: "aurora:get-character", reqId }, "*");
    });
  }, []);

  // ── Background CLOUD AUTOSAVE ──────────────────────────────────
  useEffect(() => {
    if (!charId || !autoEnabled) return;
    let cancelled = false;

    const tick = async () => {
      if (cancelled || savingRef.current) return;
      let fresh;
      try {
        fresh = await requestCharacterFromIframe(true);
      } catch (_) { return; }
      if (cancelled || !fresh?.data) return;
      const freshJson = JSON.stringify(fresh.data);
      if (freshJson === lastAutoJsonRef.current) return; // nothing changed
      const snapshot = { ...fresh.data, _ts: new Date().toISOString() };
      const base = mainDataRef.current || {};
      const m = metaRef.current || {};
      const payload = {
        name: (fresh.name || m.name || "Unnamed Hero").toString().trim() || "Unnamed Hero",
        char_class: (fresh.char_class || m.char_class || "").toString().trim(),
        level: Number(fresh.level || m.level || 1),
        data: withReserved(base, { auto: snapshot }),
      };
      try {
        setAutoStatus("Autosaving…");
        await api.put(`${charBase}/${charId}`, payload);
        if (cancelled) return;
        lastAutoJsonRef.current = freshJson;
        setAutosaveSnap(snapshot);
        setAutoStatus("Autosaved ✓");
        setTimeout(() => { if (!cancelled) setAutoStatus(""); }, 2200);
      } catch (_) {
        if (!cancelled) { setAutoStatus(""); }
      }
    };

    const interval = setInterval(tick, 20000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [charId, charBase, autoEnabled, requestCharacterFromIframe, withReserved]);

  // Load a saved version (main / autosave / a manual slot) into the sheet.
  const loadVersion = (which) => {
    let data, label;
    if (which === "autosave") { data = autosaveSnap; label = "Autosave"; }
    else if (which === "main") { data = mainData; label = "Quick Save"; }
    else {
      const slot = slots.find((s) => s.id === which);
      data = slot?.data; label = slot ? `slot “${slot.name}”` : "slot";
    }
    if (!data) {
      toast.error(which === "autosave" ? "No autosave found yet." : "Nothing saved there yet.");
      return;
    }
    activeDataRef.current = data;
    setActiveVersion(which);
    setSavesOpen(false);
    postToIframe({ type: "aurora:load-character", reqId: "ver-" + Date.now(), data });
    if (downloadUrl) URL.revokeObjectURL(downloadUrl);
    setDownloadUrl(makeDownloadUrl(data));
    toast.success(`Loaded ${label}.`);
  };

  // ── Manual SAVE SLOTS ──────────────────────────────────────────
  const persistSlots = async (next, successMsg) => {
    const m = metaRef.current || {};
    const payload = {
      name: (m.name || saveName || "Unnamed Hero").toString().trim() || "Unnamed Hero",
      char_class: (m.char_class || saveClass || "").toString().trim(),
      level: Number(m.level || saveLevel || 1),
      data: withReserved(mainDataRef.current || {}, { slots: next }),
    };
    await api.put(`${charBase}/${charId}`, payload);
    setSlots(next);
    if (successMsg) toast.success(successMsg);
  };

  const saveToNewSlot = async () => {
    if (!charId) { toast.error("Save the character to the cloud first, then use slots."); return; }
    if (slots.length >= MAX_SLOTS) { toast.error(`Slot limit reached (${MAX_SLOTS}). Delete one first.`); return; }
    const defName = `Slot ${slots.length + 1} — ${new Date().toLocaleDateString()}`;
    const name = window.prompt("Name this save slot:", defName);
    if (name === null) return;
    setSaving(true);
    try {
      const fresh = await requestCharacterFromIframe();
      const slot = {
        id: "slot-" + Date.now().toString(36),
        name: (name.trim() || defName).slice(0, 60),
        ts: new Date().toISOString(),
        data: fresh.data,
      };
      await persistSlots([...slotsRef.current, slot], `Saved to “${slot.name}”.`);
    } catch (e) {
      toast.error(formatErr(e));
    } finally {
      setSaving(false);
    }
  };

  const overwriteSlot = async (id) => {
    const slot = slots.find((s) => s.id === id);
    if (!slot) return;
    setSaving(true);
    try {
      const fresh = await requestCharacterFromIframe();
      const next = slotsRef.current.map((s) =>
        s.id === id ? { ...s, ts: new Date().toISOString(), data: fresh.data } : s);
      await persistSlots(next, `Overwrote “${slot.name}” with the current sheet.`);
    } catch (e) {
      toast.error(formatErr(e));
    } finally {
      setSaving(false);
    }
  };

  const deleteSlot = async (id) => {
    const slot = slots.find((s) => s.id === id);
    if (!slot) return;
    if (!window.confirm(`Delete save slot “${slot.name}”? This can't be undone.`)) return;
    try {
      await persistSlots(slotsRef.current.filter((s) => s.id !== id), `Deleted “${slot.name}”.`);
      if (activeVersion === id) setActiveVersion("main");
    } catch (e) {
      toast.error(formatErr(e));
    }
  };

  const saveCurrentSheetToCloud = async () => {
    setSaving(true);
    setError("");
    try {
      const fromIframe = await requestCharacterFromIframe();
      const cleanData = { ...fromIframe.data, _qsaved_at: new Date().toISOString() };
      const payload = {
        name: (saveName || fromIframe.name || "Unnamed Hero").trim(),
        char_class: (saveClass || fromIframe.char_class || "").trim(),
        level: Number(saveLevel || fromIframe.level || 1),
        // Preserve autosave snapshot + slots alongside the new Quick Save.
        // The API adapter moves embedded images into PocketBase file fields.
        data: withReserved(cleanData),
      };
      if (charId) {
        await api.put(`${charBase}/${charId}`, payload);
        setMainData(cleanData);
        setActiveVersion("main");
        activeDataRef.current = cleanData;
        toast.success(adminUser ? `Saved to @${adminUser}'s codex.` : "Updated in your codex.");
      } else {
        const created = (await api.post(`/characters`, payload)).data;
        toast.success("Saved to your codex.");
        navigate(`/sheet?id=${created.id}`);
      }
      setSaveOpen(false);
    } catch (err) {
      const msg = formatErr(err);
      setError(msg);
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  };
  saveCurrentSheetToCloudRef.current = saveCurrentSheetToCloud;

  const handleSaveToCloud = async (e) => {
    e.preventDefault();
    const file = fileInputRef.current?.files?.[0];
    if (!file) {
      await saveCurrentSheetToCloud();
      return;
    }
    setSaving(true);
    setError("");
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const payload = {
        name: saveName.trim() || "Unnamed Hero",
        char_class: saveClass.trim(),
        level: Number(saveLevel) || 1,
        data: data,
      };
      if (charId) {
        await api.put(`${charBase}/${charId}`, payload);
        const { main, auto, slots: sl } = splitBlob(data);
        setMainData(main);
        setAutosaveSnap(auto);
        setSlots(sl);
        setActiveVersion("main");
        activeDataRef.current = main;
        lastAutoJsonRef.current = auto ? JSON.stringify(stripTs(auto)) : "";
        postToIframe({ type: "aurora:load-character", reqId: "upload-" + Date.now(), data: main });
        if (downloadUrl) URL.revokeObjectURL(downloadUrl);
        setDownloadUrl(makeDownloadUrl(main));
        toast.success(adminUser ? `Saved to @${adminUser}'s codex.` : "Updated in your codex.");
      } else {
        const created = (await api.post(`/characters`, payload)).data;
        toast.success("Saved to your codex.");
        navigate(`/sheet?id=${created.id}`);
      }
      setSaveOpen(false);
    } catch (err) {
      const msg = formatErr(err);
      setError(msg);
    } finally {
      setSaving(false);
    }
  };

  const hasAutosave = !!autosaveSnap;

  // ── Shared UI pieces ───────────────────────────────────────────
  // NOTE: the name input is inlined (not a nested component) so React
  // doesn't remount it on every keystroke and steal focus.
  const onNameChange = (e) => {
    const v = e.target.value;
    setSaveName(v);
    postToIframe({ type: "aurora:set-name", name: v });
  };
  const nameInputCls = "font-cormorant italic text-parchment text-base leading-tight bg-transparent border-b border-transparent hover:border-edge focus:border-gold outline-none px-0 py-0.5 min-w-0 w-full max-w-[26ch] rounded-none";

  const menuBtnCls = "px-3 py-1.5 border border-gold/40 text-gold hover:bg-gold/10 hover:border-gold font-cinzel text-[10px] tracking-[0.2em] uppercase btn-press transition-colors whitespace-nowrap";
  const primaryBtnCls = "px-4 py-1.5 bg-crimson hover:bg-crimson-dark text-parchment font-cinzel text-[10px] tracking-[0.2em] uppercase border border-crimson/60 btn-press disabled:opacity-50 whitespace-nowrap";

  const SavesMenu = () => (
    <div className="relative">
      <button
        onClick={() => setSavesOpen((v) => !v)}
        data-testid="sheet-saves-btn"
        title="Save slots, versions, autosave & JSON import/export"
        className={menuBtnCls}
      >
        ⧉ Saves
      </button>
      {savesOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setSavesOpen(false)} />
          <div
            data-testid="sheet-saves-menu"
            className="absolute right-0 mt-1 w-72 bg-ink-surface border border-edge z-50 shadow-2xl max-h-[70vh] overflow-y-auto"
          >
            <p className="px-3 pt-2.5 pb-1 font-cinzel text-[8px] tracking-[0.35em] uppercase text-parchment-muted/70">Versions</p>
            <button
              onClick={() => loadVersion("main")}
              data-testid="version-option-main"
              className={`w-full text-left px-3 py-2 hover:bg-gold/10 ${activeVersion === "main" ? "bg-gold/5" : ""}`}
            >
              <span className="font-cinzel text-[10px] tracking-[0.2em] uppercase text-gold">⚡ Quick Save {activeVersion === "main" ? "•" : ""}</span>
              <span className="block font-cormorant text-xs text-parchment-muted">
                Cloud · {relTime(mainData?._qsaved_at) || relTime(meta?.updated_at) || "manual save"}
              </span>
            </button>
            <button
              onClick={() => loadVersion("autosave")}
              disabled={!hasAutosave}
              data-testid="version-option-autosave"
              className={`w-full text-left px-3 py-2 hover:bg-gold/10 disabled:opacity-40 ${activeVersion === "autosave" ? "bg-gold/5" : ""}`}
            >
              <span className="font-cinzel text-[10px] tracking-[0.2em] uppercase text-gold">⟲ Autosave {activeVersion === "autosave" ? "•" : ""}</span>
              <span className="block font-cormorant text-xs text-parchment-muted">
                {hasAutosave ? `Cloud · ${relTime(autosaveSnap?._ts) || "saved"}` : "No autosave yet"}
              </span>
            </button>
            <label className="flex items-center gap-2 px-3 py-2 border-t border-edge cursor-pointer">
              <input
                type="checkbox"
                checked={autoEnabled}
                onChange={(e) => setAutoEnabled(e.target.checked)}
                data-testid="autosave-toggle"
              />
              <span className="font-cormorant text-xs text-parchment-muted">Auto-save to cloud every 20s</span>
            </label>

            <p className="px-3 pt-2.5 pb-1 font-cinzel text-[8px] tracking-[0.35em] uppercase text-parchment-muted/70 border-t border-edge">
              Save Slots · {slots.length}/{MAX_SLOTS}
            </p>
            {slots.length === 0 && (
              <p className="px-3 pb-2 font-cormorant text-xs text-parchment-muted italic">
                No slots yet — snapshot the sheet any time.
              </p>
            )}
            {slots.map((s, i) => (
              <div
                key={s.id}
                data-testid={`save-slot-item-${i}`}
                className={`flex items-center gap-1 px-3 py-1.5 hover:bg-gold/10 group ${activeVersion === s.id ? "bg-gold/5" : ""}`}
              >
                <button
                  onClick={() => loadVersion(s.id)}
                  data-testid={`save-slot-load-${i}`}
                  title="Load this slot into the sheet"
                  className="flex-1 min-w-0 text-left"
                >
                  <span className="block font-cinzel text-[10px] tracking-[0.12em] uppercase text-parchment truncate">
                    ◈ {s.name} {activeVersion === s.id ? "•" : ""}
                  </span>
                  <span className="block font-cormorant text-xs text-parchment-muted">{relTime(s.ts) || "saved"}</span>
                </button>
                <button
                  onClick={() => overwriteSlot(s.id)}
                  disabled={saving}
                  data-testid={`save-slot-overwrite-${i}`}
                  title="Overwrite this slot with the current sheet"
                  className="px-1.5 py-1 text-parchment-muted hover:text-gold text-xs opacity-60 group-hover:opacity-100 transition-opacity"
                >
                  ⤓
                </button>
                <button
                  onClick={() => deleteSlot(s.id)}
                  data-testid={`save-slot-delete-${i}`}
                  title="Delete this slot"
                  className="px-1.5 py-1 text-parchment-muted hover:text-crimson text-xs opacity-60 group-hover:opacity-100 transition-opacity"
                >
                  ✕
                </button>
              </div>
            ))}
            <button
              onClick={saveToNewSlot}
              disabled={saving || slots.length >= MAX_SLOTS}
              data-testid="save-slot-create-btn"
              className="w-full text-left px-3 py-2 border-t border-edge border-dashed text-gold hover:bg-gold/10 font-cinzel text-[10px] tracking-[0.2em] uppercase disabled:opacity-40"
            >
              ＋ Save to new slot
            </button>

            <p className="px-3 pt-2.5 pb-1 font-cinzel text-[8px] tracking-[0.35em] uppercase text-parchment-muted/70 border-t border-edge">File</p>
            {downloadUrl && (
              <a
                href={downloadUrl}
                download={`${(meta?.name || saveName || "character").replace(/[^a-z0-9-_]+/gi, "_")}.json`}
                data-testid="sheet-download-json"
                onClick={() => setSavesOpen(false)}
                className="block px-3 py-2 hover:bg-gold/10 font-cinzel text-[10px] tracking-[0.2em] uppercase text-parchment-muted hover:text-parchment"
              >
                ⬇ Download JSON
              </a>
            )}
            <button
              onClick={() => { setSaveOpen(true); setSavesOpen(false); if (immersive) setImmersive(false); }}
              data-testid="sheet-save-cloud-toggle"
              className="w-full text-left px-3 py-2 pb-2.5 hover:bg-gold/10 font-cinzel text-[10px] tracking-[0.2em] uppercase text-parchment-muted hover:text-parchment"
            >
              ⇪ Import JSON / Manual save
            </button>
          </div>
        </>
      )}
    </div>
  );

  // ── RENDER — one persistent tree; fullscreen is a pure CSS toggle ──
  return (
    <div className={immersive ? "fixed inset-0 z-[60] bg-ink flex flex-col" : "min-h-screen bg-ink flex flex-col"}>
      {!immersive && <Navbar />}

      {immersive ? (
        /* ── Slim immersive bar ── */
        <div
          data-testid="immersive-bar"
          className="flex items-center justify-between px-3 sm:px-4 py-1.5 bg-ink-surface/95 backdrop-blur border-b border-edge gap-3"
        >
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <button
              onClick={() => setImmersive(false)}
              data-testid="immersive-exit-btn"
              className="font-cinzel text-[10px] tracking-[0.25em] uppercase text-parchment-muted hover:text-gold transition-colors whitespace-nowrap"
              title="Exit fullscreen (Esc)"
            >
              ✕ Exit
            </button>
            <span className="text-edge">|</span>
            {adminUser && (
              <span data-testid="sheet-admin-banner" className="font-cinzel text-[9px] tracking-[0.2em] uppercase text-crimson whitespace-nowrap">
                Admin · @{adminUser}
              </span>
            )}
            <input
              data-testid="sheet-meta-name-immersive"
              value={saveName}
              onChange={onNameChange}
              placeholder="Unsaved hero — type a name…"
              className={nameInputCls}
            />
            {autoStatus && (
              <span data-testid="autosave-status-immersive" className="font-cinzel text-[9px] tracking-[0.2em] uppercase text-emerald-400/80 whitespace-nowrap">
                {autoStatus}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <SavesMenu />
            <button
              onClick={() => setLibraryOpen(true)}
              data-testid="sheet-library-btn-immersive"
              title="Browse the shared Library"
              className={menuBtnCls}
            >
              ⌘ Library
            </button>
            <button
              onClick={saveCurrentSheetToCloud}
              disabled={saving}
              data-testid="immersive-save-cloud-btn"
              className={primaryBtnCls}
            >
              {saving ? "Saving…" : "⚡ Quick Save"}
            </button>
          </div>
        </div>
      ) : (
        /* ── Normal mode toolbar ── */
        <div
          data-testid="sheet-toolbar"
          className="sticky top-16 z-30 bg-ink-surface/95 backdrop-blur border-b border-edge"
        >
          <div className="px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <Link
                to={adminUser ? "/admin" : "/dashboard"}
                data-testid="sheet-back-link"
                className="font-cinzel text-[10px] tracking-[0.25em] uppercase text-parchment-muted hover:text-gold transition-colors whitespace-nowrap"
              >
                {adminUser ? "← Vault" : "← Codex"}
              </Link>
              <span className="text-edge">|</span>
              <div className="min-w-0 flex-1">
                <p className="font-cinzel text-[9px] tracking-[0.3em] uppercase text-gold leading-none flex items-center gap-2">
                  {adminUser ? (
                    <span data-testid="sheet-admin-banner" className="text-crimson">
                      Admin · Editing @{adminUser}
                    </span>
                  ) : (charId ? "Editing" : "New Character")}
                  {autoStatus && (
                    <span data-testid="autosave-status" className="text-emerald-400/80 normal-case tracking-normal">
                      {autoStatus}
                    </span>
                  )}
                </p>
                <input
                  data-testid="sheet-meta-name"
                  value={saveName}
                  onChange={onNameChange}
                  placeholder="Unsaved hero — type a name…"
                  className={nameInputCls}
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <SavesMenu />
              <button
                onClick={() => setLibraryOpen(true)}
                data-testid="sheet-library-btn"
                title="Browse the shared Library (admin-curated magic items + spells)"
                className={menuBtnCls}
              >
                ⌘ Library
              </button>
              <button
                onClick={() => setImmersive(true)}
                data-testid="sheet-immersive-btn"
                title="Fullscreen (Shift+F)"
                className={menuBtnCls}
              >
                ⛶ Fullscreen
              </button>
              <button
                onClick={saveCurrentSheetToCloud}
                disabled={saving}
                data-testid="sheet-quicksave-btn"
                title="Save the live sheet to the cloud instantly"
                className={primaryBtnCls}
              >
                {saving ? "Saving…" : "⚡ Quick Save"}
              </button>
            </div>
          </div>

          {/* Manual save drawer */}
          {saveOpen && (
            <div className="border-t border-edge bg-ink/60 px-4 sm:px-6 py-3">
              <form
                onSubmit={handleSaveToCloud}
                data-testid="cloud-save-form"
                className="grid grid-cols-1 md:grid-cols-6 gap-3 items-end"
              >
                <div className="md:col-span-2">
                  <label className="block font-cinzel text-[9px] tracking-[0.3em] uppercase text-parchment-muted mb-1">
                    Hero name
                  </label>
                  <input
                    data-testid="cloud-save-name"
                    required
                    value={saveName}
                    onChange={(e) => setSaveName(e.target.value)}
                    className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-1.5 font-cormorant text-parchment rounded-none text-sm"
                    placeholder="Aurora the Bold"
                  />
                </div>
                <div>
                  <label className="block font-cinzel text-[9px] tracking-[0.3em] uppercase text-parchment-muted mb-1">
                    Class
                  </label>
                  <input
                    data-testid="cloud-save-class"
                    value={saveClass}
                    onChange={(e) => setSaveClass(e.target.value)}
                    className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-1.5 font-cormorant text-parchment rounded-none text-sm"
                    placeholder="Bard"
                  />
                </div>
                <div>
                  <label className="block font-cinzel text-[9px] tracking-[0.3em] uppercase text-parchment-muted mb-1">
                    Level
                  </label>
                  <input
                    data-testid="cloud-save-level"
                    type="number"
                    min={1}
                    max={20}
                    value={saveLevel}
                    onChange={(e) => setSaveLevel(e.target.value)}
                    className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-1.5 font-cormorant text-parchment rounded-none text-sm"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block font-cinzel text-[9px] tracking-[0.3em] uppercase text-parchment-muted mb-1">
                    JSON file (optional — empty pulls the live sheet)
                  </label>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="application/json,.json"
                    data-testid="cloud-save-file"
                    className="block w-full text-xs text-parchment-muted font-cormorant
                      file:mr-3 file:py-1.5 file:px-3 file:border-0 file:bg-gold/10 file:text-gold
                      file:font-cinzel file:text-[10px] file:tracking-[0.2em] file:uppercase"
                  />
                </div>
                <div className="md:col-span-6 flex items-center justify-between flex-wrap gap-3">
                  {error && (
                    <p data-testid="cloud-save-error" className="text-crimson font-cormorant text-sm">
                      {error}
                    </p>
                  )}
                  <div className="flex gap-2 ml-auto">
                    <button
                      type="button"
                      onClick={() => setSaveOpen(false)}
                      data-testid="cloud-save-cancel"
                      className="px-4 py-1.5 text-parchment-muted hover:text-parchment font-cinzel text-[10px] tracking-[0.2em] uppercase"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      data-testid="cloud-save-submit"
                      className="px-5 py-1.5 bg-crimson hover:bg-crimson-dark text-parchment font-cinzel text-[10px] tracking-[0.2em] uppercase border border-edge btn-press disabled:opacity-50"
                    >
                      {saving ? "Sealing…" : (charId ? "Update" : "Save")}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* THE one iframe — persistent across fullscreen toggles (no reload) */}
      <iframe
        key="aurora-frame"
        ref={iframeRef}
        data-testid="aurora-iframe"
        title="Aurora D&D 2024 Character Sheet"
        src={charId ? "/sheet/aurora.html?continue=1" : "/sheet/aurora.html"}
        allow="downloads"
        className="w-full flex-1"
        style={{
          background: "#0F0C0B",
          border: 0,
          display: "block",
          ...(immersive ? {} : { height: `calc(100vh - ${saveOpen ? 240 : 110}px)`, minHeight: 600 }),
        }}
      />
      <LibraryBrowser
        open={libraryOpen}
        onClose={() => setLibraryOpen(false)}
        iframeWindow={iframeRef.current?.contentWindow}
      />
    </div>
  );
}

// Strip the autosave timestamp so dirty-checking compares only sheet data.
function stripTs(snap) {
  if (!snap || typeof snap !== "object") return snap;
  const { _ts, ...rest } = snap;
  return rest;
}
