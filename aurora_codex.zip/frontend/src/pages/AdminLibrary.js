import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { api, formatApiErrorDetail } from "../lib/api";
import Navbar from "../components/Navbar";
import { toast } from "sonner";

// ────────────────────────────────────────────────────────────────────
//   /admin/library — Magic Items + Spells library (admin-only).
//   Tables live in Supabase (`aurora_magic_items`, `aurora_spells`).
//   Players see everything in this library via the "+ from Library"
//   buttons inside the sheet (different code path).
// ────────────────────────────────────────────────────────────────────

const RARITIES = ["Common", "Uncommon", "Rare", "Very Rare", "Legendary", "Artifact"];
const ITEM_TYPES = ["Wondrous", "Weapon", "Armor", "Shield", "Potion", "Scroll", "Ring", "Rod", "Staff", "Wand"];
const SCHOOLS = ["Abjuration", "Conjuration", "Divination", "Enchantment", "Evocation", "Illusion", "Necromancy", "Transmutation"];

const fmtErr = (e) => formatApiErrorDetail(e?.response?.data) || e?.message || String(e);

function FieldLabel({ children }) {
  return (
    <label className="block font-cinzel text-[9px] tracking-[0.3em] uppercase text-parchment-muted mb-1">
      {children}
    </label>
  );
}

const EMPTY_ITEM = { name: "", rarity: "Common", item_type: "Wondrous", attunement: false, charges: "", description: "" };
const EMPTY_SPELL = { name: "", level: 0, school: "Evocation", casting_time: "1 Action", range_text: "Self", components: "V, S", duration: "Instantaneous", description: "", higher_levels: "" };

export default function AdminLibrary() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState("items");
  const [items, setItems] = useState([]);
  const [spells, setSpells] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState(null);   // {} = new, null = closed
  const [editingSpell, setEditingSpell] = useState(null);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");

  // Admin-only gate. Bounce non-admins to the dashboard.
  useEffect(() => {
    if (user && user.role !== "admin") navigate("/dashboard", { replace: true });
  }, [user, navigate]);

  const load = async () => {
    setLoading(true);
    try {
      const [i, s] = await Promise.all([
        api.get("/library/magic-items"),
        api.get("/library/spells"),
      ]);
      setItems(i.data || []);
      setSpells(s.data || []);
    } catch (e) {
      toast.error(fmtErr(e));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  // ── Magic-item CRUD ──
  const saveItem = async (form) => {
    setSaving(true);
    try {
      if (form.id) await api.put(`/library/magic-items/${form.id}`, form);
      else await api.post(`/library/magic-items`, form);
      toast.success(`Saved "${form.name}"`);
      setEditingItem(null);
      await load();
    } catch (e) { toast.error(fmtErr(e)); }
    finally { setSaving(false); }
  };
  const deleteItem = async (it) => {
    if (!window.confirm(`Delete "${it.name}"?`)) return;
    try {
      await api.delete(`/library/magic-items/${it.id}`);
      toast.success("Deleted");
      await load();
    } catch (e) { toast.error(fmtErr(e)); }
  };

  // ── Spell CRUD ──
  const saveSpell = async (form) => {
    setSaving(true);
    try {
      if (form.id) await api.put(`/library/spells/${form.id}`, form);
      else await api.post(`/library/spells`, form);
      toast.success(`Saved "${form.name}"`);
      setEditingSpell(null);
      await load();
    } catch (e) { toast.error(fmtErr(e)); }
    finally { setSaving(false); }
  };
  const deleteSpell = async (sp) => {
    if (!window.confirm(`Delete "${sp.name}"?`)) return;
    try {
      await api.delete(`/library/spells/${sp.id}`);
      toast.success("Deleted");
      await load();
    } catch (e) { toast.error(fmtErr(e)); }
  };

  const filter = (rows, fields) =>
    !search ? rows : rows.filter((r) => fields.some((f) => String(r[f] || "").toLowerCase().includes(search.toLowerCase())));

  return (
    <div className="min-h-screen bg-ink text-parchment">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-end justify-between gap-3 mb-5">
          <div>
            <p className="font-cinzel text-gold text-[10px] tracking-[0.4em] uppercase">DM Workshop</p>
            <h1 className="font-cormorant italic text-parchment text-4xl">Library</h1>
            <p className="font-cormorant italic text-parchment-dim text-sm mt-1">
              Shared with every player. Add magic items and spells here, then your players will see them
              under the &quot;+ from Library&quot; button inside the sheet.
            </p>
          </div>
          <Link to="/admin" data-testid="back-to-admin"
            className="font-cinzel text-[10px] tracking-[0.25em] uppercase text-parchment-muted hover:text-parchment">
            ← DM Vault
          </Link>
        </div>

        {/* Tab strip */}
        <div className="flex gap-0 border-b border-edge mb-4">
          {["items", "spells"].map((t) => (
            <button
              key={t}
              type="button"
              data-testid={`library-tab-${t}`}
              onClick={() => setTab(t)}
              className={
                "px-5 py-2 font-cinzel text-[10px] tracking-[0.25em] uppercase transition-colors " +
                (tab === t ? "text-gold border-b-2 border-gold" : "text-parchment-muted hover:text-parchment")
              }
            >
              {t === "items" ? "Magic Items" : "Spells"} ({t === "items" ? items.length : spells.length})
            </button>
          ))}
        </div>

        <div className="flex flex-wrap gap-3 mb-4">
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name…"
            data-testid="library-search"
            className="flex-1 min-w-[200px] bg-ink/60 border border-edge focus:border-gold outline-none px-3 py-2 font-cormorant text-parchment"
          />
          {tab === "items" && (
            <button
              type="button"
              onClick={() => setEditingItem({ ...EMPTY_ITEM })}
              data-testid="new-item-button"
              className="px-4 py-2 bg-crimson hover:bg-crimson-dark text-parchment font-cinzel text-[10px] tracking-[0.25em] uppercase border border-edge"
            >
              ＋ New Magic Item
            </button>
          )}
          {tab === "spells" && (
            <button
              type="button"
              onClick={() => setEditingSpell({ ...EMPTY_SPELL })}
              data-testid="new-spell-button"
              className="px-4 py-2 bg-crimson hover:bg-crimson-dark text-parchment font-cinzel text-[10px] tracking-[0.25em] uppercase border border-edge"
            >
              ＋ New Spell
            </button>
          )}
        </div>

        {loading && <p className="font-cormorant italic text-parchment-muted">Loading library…</p>}

        {!loading && tab === "items" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3" data-testid="items-grid">
            {filter(items, ["name", "rarity", "item_type", "description"]).map((it) => (
              <div key={it.id} className="border border-edge bg-leather/40 p-4 flex flex-col gap-1" data-testid={`item-row-${it.id}`}>
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-cormorant italic text-parchment text-xl leading-tight">{it.name}</h3>
                  <span className="font-cinzel text-[9px] uppercase tracking-[0.2em] text-gold">{it.rarity}</span>
                </div>
                <p className="font-cinzel text-[9px] uppercase tracking-[0.2em] text-parchment-muted">
                  {it.item_type}{it.attunement ? " · requires attunement" : ""}{it.charges ? ` · ${it.charges}` : ""}
                </p>
                <p className="font-cormorant text-parchment text-sm leading-snug mt-1 line-clamp-3 whitespace-pre-wrap">
                  {it.description || "—"}
                </p>
                <div className="flex gap-2 mt-2">
                  <button type="button" onClick={() => setEditingItem({ ...it })}
                    data-testid={`edit-item-${it.id}`}
                    className="font-cinzel text-[9px] tracking-[0.2em] uppercase px-3 py-1 border border-edge text-parchment-muted hover:text-parchment">
                    Edit
                  </button>
                  <button type="button" onClick={() => deleteItem(it)}
                    data-testid={`delete-item-${it.id}`}
                    className="font-cinzel text-[9px] tracking-[0.2em] uppercase px-3 py-1 border border-crimson/40 text-crimson hover:bg-crimson/10">
                    Delete
                  </button>
                </div>
              </div>
            ))}
            {items.length === 0 && (
              <p className="font-cormorant italic text-parchment-dim col-span-full">
                No magic items yet — hit &quot;New Magic Item&quot; above to add the first one.
              </p>
            )}
          </div>
        )}

        {!loading && tab === "spells" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3" data-testid="spells-grid">
            {filter(spells, ["name", "school", "description"]).map((sp) => (
              <div key={sp.id} className="border border-edge bg-leather/40 p-4 flex flex-col gap-1" data-testid={`spell-row-${sp.id}`}>
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-cormorant italic text-parchment text-xl leading-tight">{sp.name}</h3>
                  <span className="font-cinzel text-[9px] uppercase tracking-[0.2em] text-gold">
                    {sp.level === 0 ? "Cantrip" : `Level ${sp.level}`}
                  </span>
                </div>
                <p className="font-cinzel text-[9px] uppercase tracking-[0.2em] text-parchment-muted">
                  {sp.school} · {sp.casting_time} · {sp.range_text} · {sp.duration}
                </p>
                <p className="font-cormorant text-parchment text-sm leading-snug mt-1 line-clamp-3 whitespace-pre-wrap">
                  {sp.description || "—"}
                </p>
                <div className="flex gap-2 mt-2">
                  <button type="button" onClick={() => setEditingSpell({ ...sp })}
                    data-testid={`edit-spell-${sp.id}`}
                    className="font-cinzel text-[9px] tracking-[0.2em] uppercase px-3 py-1 border border-edge text-parchment-muted hover:text-parchment">
                    Edit
                  </button>
                  <button type="button" onClick={() => deleteSpell(sp)}
                    data-testid={`delete-spell-${sp.id}`}
                    className="font-cinzel text-[9px] tracking-[0.2em] uppercase px-3 py-1 border border-crimson/40 text-crimson hover:bg-crimson/10">
                    Delete
                  </button>
                </div>
              </div>
            ))}
            {spells.length === 0 && (
              <p className="font-cormorant italic text-parchment-dim col-span-full">
                No spells yet — hit &quot;New Spell&quot; above to add the first one.
              </p>
            )}
          </div>
        )}
      </div>

      {editingItem && (
        <ItemEditor
          initial={editingItem}
          onCancel={() => setEditingItem(null)}
          onSave={saveItem}
          saving={saving}
        />
      )}
      {editingSpell && (
        <SpellEditor
          initial={editingSpell}
          onCancel={() => setEditingSpell(null)}
          onSave={saveSpell}
          saving={saving}
        />
      )}
    </div>
  );
}

// ── Magic-item editor modal ──────────────────────────────────────────
function ItemEditor({ initial, onCancel, onSave, saving }) {
  const [f, setF] = useState(initial);
  const u = (k, v) => setF((p) => ({ ...p, [k]: v }));
  return (
    <div className="fixed inset-0 z-50 bg-ink/85 backdrop-blur-sm flex items-start sm:items-center justify-center px-3 py-6 overflow-y-auto"
      onClick={(e) => { if (e.target === e.currentTarget && !saving) onCancel(); }}>
      <div className="bg-leather border border-gold/40 w-full max-w-2xl shadow-2xl my-4">
        <div className="px-6 py-4 border-b border-edge">
          <p className="font-cinzel text-gold text-[10px] tracking-[0.4em] uppercase">Magic Item</p>
          <h2 className="font-cormorant italic text-parchment text-2xl">{f.id ? "Edit" : "New Magic Item"}</h2>
        </div>
        <div className="px-6 py-4 space-y-3">
          <div>
            <FieldLabel>Name</FieldLabel>
            <input value={f.name} onChange={(e) => u("name", e.target.value)} autoFocus
              data-testid="item-name"
              className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment"
              placeholder="e.g. Boots of Springing & Striding" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <FieldLabel>Rarity</FieldLabel>
              <select value={f.rarity} onChange={(e) => u("rarity", e.target.value)} data-testid="item-rarity"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment">
                {RARITIES.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
            <div>
              <FieldLabel>Type</FieldLabel>
              <select value={f.item_type} onChange={(e) => u("item_type", e.target.value)} data-testid="item-type"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment">
                {ITEM_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <FieldLabel>Charges</FieldLabel>
              <input value={f.charges} onChange={(e) => u("charges", e.target.value)}
                data-testid="item-charges"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment"
                placeholder="e.g. 3/day or 7 charges" />
            </div>
          </div>
          <label className="flex items-center gap-2 text-parchment font-cormorant text-sm">
            <input type="checkbox" checked={!!f.attunement} onChange={(e) => u("attunement", e.target.checked)} data-testid="item-attunement" />
            Requires attunement
          </label>
          <div>
            <FieldLabel>Description</FieldLabel>
            <textarea value={f.description} onChange={(e) => u("description", e.target.value)}
              data-testid="item-description"
              rows={6}
              className="w-full bg-ink/60 border border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment"
              placeholder="Effects, properties, lore…" />
          </div>
        </div>
        <div className="px-6 py-3 border-t border-edge flex justify-end gap-2">
          <button type="button" onClick={onCancel} disabled={saving} data-testid="item-cancel"
            className="font-cinzel text-[10px] tracking-[0.25em] uppercase text-parchment-muted hover:text-parchment disabled:opacity-50">
            Cancel
          </button>
          <button type="button" onClick={() => onSave(f)} disabled={saving || !f.name.trim()} data-testid="item-save"
            className="px-5 py-2 bg-crimson hover:bg-crimson-dark text-parchment font-cinzel text-[10px] tracking-[0.25em] uppercase border border-edge disabled:opacity-50">
            {saving ? "Saving…" : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Spell editor modal ───────────────────────────────────────────────
function SpellEditor({ initial, onCancel, onSave, saving }) {
  const [f, setF] = useState(initial);
  const u = (k, v) => setF((p) => ({ ...p, [k]: v }));
  return (
    <div className="fixed inset-0 z-50 bg-ink/85 backdrop-blur-sm flex items-start sm:items-center justify-center px-3 py-6 overflow-y-auto"
      onClick={(e) => { if (e.target === e.currentTarget && !saving) onCancel(); }}>
      <div className="bg-leather border border-gold/40 w-full max-w-2xl shadow-2xl my-4">
        <div className="px-6 py-4 border-b border-edge">
          <p className="font-cinzel text-gold text-[10px] tracking-[0.4em] uppercase">Spell</p>
          <h2 className="font-cormorant italic text-parchment text-2xl">{f.id ? "Edit" : "New Spell"}</h2>
        </div>
        <div className="px-6 py-4 space-y-3">
          <div>
            <FieldLabel>Name</FieldLabel>
            <input value={f.name} onChange={(e) => u("name", e.target.value)} autoFocus
              data-testid="spell-name"
              className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment"
              placeholder="e.g. Whispered Verdict" />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <FieldLabel>Level</FieldLabel>
              <select value={f.level} onChange={(e) => u("level", parseInt(e.target.value))} data-testid="spell-level"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment">
                <option value={0}>Cantrip</option>
                {[1,2,3,4,5,6,7,8,9].map((l) => <option key={l} value={l}>Level {l}</option>)}
              </select>
            </div>
            <div>
              <FieldLabel>School</FieldLabel>
              <select value={f.school} onChange={(e) => u("school", e.target.value)} data-testid="spell-school"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment">
                {SCHOOLS.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <FieldLabel>Casting Time</FieldLabel>
              <input value={f.casting_time} onChange={(e) => u("casting_time", e.target.value)} data-testid="spell-time"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment" />
            </div>
            <div>
              <FieldLabel>Range</FieldLabel>
              <input value={f.range_text} onChange={(e) => u("range_text", e.target.value)} data-testid="spell-range"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment" />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <FieldLabel>Components</FieldLabel>
              <input value={f.components} onChange={(e) => u("components", e.target.value)} data-testid="spell-components"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment"
                placeholder="V, S, M (a pinch of dust)" />
            </div>
            <div>
              <FieldLabel>Duration</FieldLabel>
              <input value={f.duration} onChange={(e) => u("duration", e.target.value)} data-testid="spell-duration"
                className="w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment" />
            </div>
          </div>
          <div>
            <FieldLabel>Description</FieldLabel>
            <textarea value={f.description} onChange={(e) => u("description", e.target.value)} data-testid="spell-description"
              rows={6}
              className="w-full bg-ink/60 border border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment"
              placeholder="What the spell does…" />
          </div>
          <div>
            <FieldLabel>At Higher Levels</FieldLabel>
            <textarea value={f.higher_levels} onChange={(e) => u("higher_levels", e.target.value)} data-testid="spell-higher"
              rows={3}
              className="w-full bg-ink/60 border border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment"
              placeholder="When cast using a higher-level slot…" />
          </div>
        </div>
        <div className="px-6 py-3 border-t border-edge flex justify-end gap-2">
          <button type="button" onClick={onCancel} disabled={saving} data-testid="spell-cancel"
            className="font-cinzel text-[10px] tracking-[0.25em] uppercase text-parchment-muted hover:text-parchment disabled:opacity-50">
            Cancel
          </button>
          <button type="button" onClick={() => onSave(f)} disabled={saving || !f.name.trim()} data-testid="spell-save"
            className="px-5 py-2 bg-crimson hover:bg-crimson-dark text-parchment font-cinzel text-[10px] tracking-[0.25em] uppercase border border-edge disabled:opacity-50">
            {saving ? "Saving…" : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
}
