import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import Navbar from "../components/Navbar";
import { toast } from "sonner";

export default function Account() {
  const { user, changePassword, updateName } = useAuth();

  const [name, setName] = useState(user?.name || "");
  const [savingName, setSavingName] = useState(false);

  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [pwError, setPwError] = useState("");
  const [savingPw, setSavingPw] = useState(false);

  if (!user) return null;

  const saveName = async (e) => {
    e.preventDefault();
    setSavingName(true);
    const res = await updateName(name.trim());
    setSavingName(false);
    if (res.ok) toast.success("Display name updated.");
    else toast.error(res.error);
  };

  const savePw = async (e) => {
    e.preventDefault();
    setPwError("");
    if (newPassword.length < 8) return setPwError("New password must be at least 8 characters.");
    if (newPassword !== confirm) return setPwError("New passwords do not match.");
    setSavingPw(true);
    const res = await changePassword({ oldPassword, newPassword });
    setSavingPw(false);
    if (res.ok) {
      toast.success("Password changed.");
      setOldPassword(""); setNewPassword(""); setConfirm("");
    } else {
      setPwError(res.error || "Could not change password.");
    }
  };

  const inputCls =
    "w-full bg-ink/60 border-b border-edge focus:border-gold outline-none px-2 py-2 font-cormorant text-parchment rounded-none";
  const labelCls =
    "block font-cinzel text-[10px] tracking-[0.3em] uppercase text-parchment-muted mb-2";
  const btnCls =
    "px-6 py-3 bg-crimson hover:bg-crimson-dark text-parchment font-cinzel tracking-[0.22em] uppercase text-xs border border-edge btn-press disabled:opacity-50";

  return (
    <div className="min-h-screen bg-leather">
      <Navbar />
      <main className="pt-32 pb-20 px-6">
        <div className="max-w-xl mx-auto">
          <p className="font-cinzel text-gold text-xs tracking-[0.4em] uppercase mb-3">❖ Your Account</p>
          <h1 data-testid="account-title" className="font-cinzel text-parchment text-4xl mb-2">
            Account Settings
          </h1>
          <p className="font-cormorant italic text-parchment-muted mb-10">
            Signed in as <span className="text-gold">@{user.username}</span>
            {user.role === "admin" ? " · Dungeon Master" : ""}.
          </p>

          <form data-testid="name-form" onSubmit={saveName} className="bg-ink-surface border border-edge p-8 space-y-5 mb-8">
            <h2 className="font-cinzel text-parchment text-xl">Display Name</h2>
            <div>
              <label className={labelCls}>Display name</label>
              <input data-testid="account-name-input" className={inputCls} value={name}
                onChange={(e) => setName(e.target.value)} maxLength={80} required />
            </div>
            <button type="submit" disabled={savingName} data-testid="account-name-save" className={btnCls}>
              {savingName ? "Saving…" : "Save name"}
            </button>
          </form>

          <form data-testid="password-form" onSubmit={savePw} className="bg-ink-surface border border-edge p-8 space-y-5">
            <h2 className="font-cinzel text-parchment text-xl">Change Password</h2>
            <div>
              <label className={labelCls}>Current password</label>
              <input data-testid="account-oldpw-input" type="password" className={inputCls}
                value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} required autoComplete="current-password" />
            </div>
            <div>
              <label className={labelCls}>New password</label>
              <input data-testid="account-newpw-input" type="password" className={inputCls}
                value={newPassword} onChange={(e) => setNewPassword(e.target.value)} minLength={8} required autoComplete="new-password" />
            </div>
            <div>
              <label className={labelCls}>Confirm new password</label>
              <input data-testid="account-confirmpw-input" type="password" className={inputCls}
                value={confirm} onChange={(e) => setConfirm(e.target.value)} minLength={8} required autoComplete="new-password" />
            </div>
            {pwError && (
              <div data-testid="account-pw-error" className="text-crimson border border-crimson/30 bg-crimson/10 px-4 py-3 font-cormorant text-sm">
                {pwError}
              </div>
            )}
            <button type="submit" disabled={savingPw} data-testid="account-pw-save" className={btnCls}>
              {savingPw ? "Updating…" : "Change password"}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
