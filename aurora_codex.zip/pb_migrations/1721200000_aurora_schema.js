/// <reference path="../pb_data/types.d.ts" />
//
// Aurora D&D Codex — PocketBase schema migration.
//
// Applies the full collection set (users auth + characters + magic_items +
// spells) from collections_snapshot.json. Drop this file (and the snapshot)
// into a self-hosted PocketBase `pb_migrations/` directory and it is applied
// automatically on startup. It is idempotent: `importCollections(..., false)`
// merges/updates by name without deleting anything not in the list.
//
// The canonical, human-readable definition also lives in
// /app/scripts/pb_setup.py (creates the same schema via the REST API).

migrate(
  (app) => {
    const snapshot = require(`${__hooks}/../pb_migrations/collections_snapshot.json`);
    // deleteMissing = false → never remove collections/data not in the snapshot.
    app.importCollections(snapshot, false);
  },
  (app) => {
    // Down: remove only the app collections we added (keeps `users` + data safe).
    for (const name of ["spells", "magic_items", "characters"]) {
      try {
        const c = app.findCollectionByNameOrId(name);
        app.delete(c);
      } catch (_) { /* already gone */ }
    }
  }
);
