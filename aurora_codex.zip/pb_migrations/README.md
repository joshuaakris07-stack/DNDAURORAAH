# Aurora — PocketBase schema & migrations

PocketBase (Fly.io) is the app's main **database, auth, and file storage**.
This directory contains the reproducible schema so the instance can be rebuilt
from scratch.

## Collections

| Collection      | Type | Purpose                                             |
|-----------------|------|-----------------------------------------------------|
| `users`         | auth | Players + DMs. Login by **username**; `role` = `user`\|`admin`. Email optional. |
| `characters`    | base | `owner`→users (cascade), `name`, `char_class`, `level`, `portrait` (file), `data` (json ≤20MB), autodate `created`/`updated`. |
| `magic_items`   | base | Shared library (admin-managed).                     |
| `spells`        | base | Shared library (admin-managed).                     |

### API rules (enforced by PocketBase — no superuser used in the frontend)
- **users**: list = admin only; view = self or admin; create = open but only
  `role="user"`; update = self (role locked) or admin; delete = admin.
- **characters**: all ops = `owner == auth.id` **or** `auth.role = "admin"`.
- **magic_items / spells**: read = any authed user; write = admin only.

## How to apply

**Option A — Admin UI (quickest):**
Dashboard → *Settings* → *Import collections* → upload
`collections_snapshot.json` → keep "merge" (do NOT enable delete) → Apply.

**Option B — Migration file (self-hosted):**
Mount this folder as the PocketBase `pb_migrations/` directory. On startup PB
runs `1721200000_aurora_schema.js`, which imports the snapshot idempotently.

**Option C — Script (from this repo):**
`python3 scripts/pb_setup.py` recreates the exact same schema over the REST API
(reads superuser creds from `backend/.env`, never committed).

## Data migration
`python3 scripts/pb_migrate_data.py` performs the one-time Supabase → PocketBase
import (users with a temp password, characters + portraits, library). Idempotent.

> **Secrets:** superuser credentials live only in `backend/.env` (git-ignored).
> Never place them in frontend code or commit them.
